import { DefaultFooter } from '@ant-design/pro-components';
// import { useIntl } from '@umijs/max';
import React from 'react';

const Footer: React.FC = () => {
  // const intl = useIntl();
  // const defaultMessage = intl.formatMessage({
  //   id: 'app.copyright.produced',
  //   defaultMessage: 'wetech版权所有',
  // });

  const currentYear = new Date().getFullYear();

  return (
    <DefaultFooter
      style={{
        background: 'none',
      }}
      copyright={`${currentYear} ${'wetech版权所有'}`}
    />
  );
};

export default Footer;
